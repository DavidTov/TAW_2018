<?php 
	include_once "header.php"
	$before_login=true;
	include_once "menu.php";
?>
	<h2>Book Management System</h2>
<?php
	include_once "footer.php";
?>

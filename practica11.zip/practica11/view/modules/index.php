<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
</head>

<body>



<?php 
	include_once "header.php";
	$before_login=true;
	include_once "menu.php";
?>

	<center><h2>Book Management System</h2></center>
<?php
	include_once "footer.php";
?>



</body>


</html>
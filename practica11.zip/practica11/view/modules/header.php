<html>
	<head>
		<!-- SE LLAMA AL ARCHIVO CSS QUE CONTIENE LOS ESTILOS -->
		<link rel="stylesheet" type="text/css" href="view/css/navegacion.css">
		<link rel="stylesheet" type="text/css" href="view/css/tabla.css">

		 <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet"> 

		 <link href="https://fonts.googleapis.com/css?family=Dancing+Script|Lobster" rel="stylesheet"> 
	</head>	

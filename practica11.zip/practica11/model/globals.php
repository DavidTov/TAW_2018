<?php
	$db_server="localhost";
	$db_username="admin";
	$db_password="53755c97ea6e4ef9940a4317edc7185434238be40224765c";
	$db_name="bms";
?>

<?php 

	include "db/database_utilities.php";

	echo "Datos de los usuarios";
	echo "<br>";
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title> Alumnos y tutores </title>
 </head>
 <body>
 	<table>
 		<thead>
 			<th>hola</th>
 			<th>hola</th>
 			<th>hola</th>
 		</thead>
 		<tbody>
 			<tr>
 				<th>hola</th>
 				<th>hola</th>
 			</tr>
 		</tbody>
 	</table>

 	<br>
 	<a href="registrar_carrera.php"> Registrar carrera </a><br>
 	<a href="registrar_tutor.php"> Registrar tutor </a><br>
 	<a href="registrar_alumno.php"> Registrar alumno </a><br>
 </body>
 </html>
